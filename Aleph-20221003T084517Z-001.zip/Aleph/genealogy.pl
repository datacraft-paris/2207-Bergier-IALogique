% Simple illustration of the use of Aleph on
%       a genealogy problem


%% :- consult('~/Downloads/aleph.pl') %% Change to the actual filepath of aleph.pl on your machine

:- use_module(library(aleph)).
:- if(current_predicate(use_rendering/1)).
:- use_rendering(prolog).
:- endif.
:- aleph.
:-style_check(-discontiguous).
:- aleph_set(i,2).



%% Mode of search and typing
:- mode(*,parent(+person,+person)).
:- mode(*,male(+person)).
:- mode(*,female(+person)).
:- mode(*,daughter(+person,+person)).

%% :- determination(targetPredicate, explainingPredicate).
:- determination(daughter/2,parent/2).
:- determination(daughter/2,male/1).
:- determination(daughter/2,female/1).




:-begin_bg.
% Background Knowledge:

parent(helen, mary).
parent(helen, tom).
parent(george, mary).
parent(tom, eve).
parent(nancy, eve).
parent(jack, tom).

female(mary).
female(helen).
female(nancy).
female(eve).

male(tom).
male(george).
:-end_bg.


:-begin_in_pos. 
% Positive examples:
daughter(mary, helen).
daughter(eve, tom).
:-end_in_pos.


:-begin_in_neg.
% Negative examples:
daughter(tom, helen).
daughter(nancy, helen).
:-end_in_neg.

