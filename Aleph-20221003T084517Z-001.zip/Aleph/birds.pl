% Simple illustration of the use of Aleph on
%       Hugo's animals problem


%% :- consult('~/Downloads/aleph.pl') %% Change to the actual filepath of aleph.pl on your machine

:- use_module(library(aleph)).
:- if(current_predicate(use_rendering/1)).
:- use_rendering(prolog).
:- endif.
:- aleph.
:-style_check(-discontiguous).
:- aleph_set(i,2).


:- mode(*,fly(+animal)).
:- mode(*,bird(+animal)).
:- mode(*,mammal(+animal)).
:- mode(*,fish(+animal)).
:- mode(*,has_wings(+animal)).
:- mode(*,lay_eggs(+animal)).
:- mode(*,nurses(+animal)).
:- mode(*,has_feathers(+animal)).
:- mode(*,vertebrate(+animal)).
:- mode(*,ostrich(+animal)).
:- mode(*,eagle(+animal)).
:- mode(*,hawk(+animal)).
:- mode(*,can_eat(+animal,+animal)).



:- determination(fly/1,bird/1).
:- determination(fly/1,mammal/1).
:- determination(fly/1,fish/1).
:- determination(fly/1,has_wings/1).
:- determination(fly/1,lay_eggs/1).
:- determination(fly/1,nurses/1).
:- determination(fly/1,has_feathers/1).
:- determination(fly/1,vertebrate/1).
:- determination(fly/1,can_eat/2).
:- determination(fly/1,ostrich/1).
:- determination(fly/1,eagle/1).
:- determination(fly/1,hawk/1).


:- dynamic bird/1.
:- dynamic mammal/1.
:- dynamic fish/1.
:- dynamic has_wings/1.
:- dynamic lay_eggs/1.
:- dynamic nurses/1.
:- dynamic has_feathers/1.
:- dynamic vertebrate/1.
:- dynamic can_eat/2.
:- dynamic ostrich/1.
:- dynamic eagle/1.
:- dynamic hawk/1.

:-begin_bg.
% type definitions


bird(rita).
bird(jena).
bird(pigo).
bird(mera).
bird(rico).
bird(mila).

mammal(tara).
mammal(chad).
mammal(giro).
mammal(turo).

fish(lana).
fish(deno).
fish(bulo).

has_wings(rita).
has_wings(jena).
has_wings(pigo).
has_wings(mera).
has_wings(rico).
has_wings(mila).


eagle(jena).
eagle(mera).
hawk(rico).
hawk(pigo).

lay_eggs(X) :- bird(X).
lay_eggs(X) :- fish(X).
nurses(X) :- mammal(X).

bird(X) :- ostrich(X).
bird(X) :- eagle(X).
bird(X) :- hawk(X).

:-end_bg.


:-begin_in_pos.

fly(pigo).
fly(jena).
fly(mera).
fly(rico).

:-end_in_pos.



:-begin_in_neg.

fly(tara).
fly(chad).
fly(giro).
fly(turo).
fly(lana).
fly(deno).
fly(bulo).

:-end_in_neg.

